MVC para operaciones CRUD
