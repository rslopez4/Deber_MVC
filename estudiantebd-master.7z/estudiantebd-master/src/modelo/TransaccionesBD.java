package modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import vista.VistaEstudiante;

public class TransaccionesBD extends Conexion {

    PreparedStatement ps;
    ResultSet rs;
    Estudiante estudiante;

    public boolean insertar(Estudiante estudiante) {
        try {
            Connection conexion = getConnection();
            ps = conexion.prepareStatement("insert into estudiante (nombreE,nota,sexo,materia) values(?,?,?,?)");
            ps.setString(1, estudiante.getNombre());
            ps.setDouble(2, estudiante.getNota());
            ps.setString(3, estudiante.getGenero());
            ps.setString(4, estudiante.getMateria());
            int resultado = ps.executeUpdate();
            if (resultado > 0) {
                return true;
            } else {
                return false;
            }
        } catch (SQLException ex) {
            System.err.println("Error revisar " + ex);
            return false;
        }

    }

    public boolean modificar(Estudiante estudiante) {
        try {
            Connection conexion = getConnection();
            ps = conexion.prepareStatement("update estudiante set nombreE=?,nota=?,sexo=?,materia=? where codigoE=?");
            ps.setString(1, estudiante.getNombre());
            ps.setDouble(2, estudiante.getNota());
            ps.setString(3, estudiante.getGenero());
            ps.setString(4, estudiante.getMateria());
            ps.setInt(5, estudiante.getCodigo());
            int resultado = ps.executeUpdate();
            if (resultado > 0) {
                return true;
            } else {
                return false;
            }

        } catch (SQLException ex) {
            System.err.println("Error revisar " + ex);
            return false;
        }
    }

    public Estudiante buscar(Estudiante estudiante) {
        Estudiante e = new Estudiante();
        try {
            Connection conexion = getConnection();
            ps = conexion.prepareStatement("select * from estudiante where codigoE=?");
            ps.setInt(1, estudiante.getCodigo());
            rs = ps.executeQuery();
            if (rs.next()) {
                e.setCodigo(rs.getInt("codigoE"));
                e.setNombre(rs.getString("nombreE"));
                e.setNota(rs.getDouble("nota"));
                e.setGenero(rs.getString("sexo"));
                e.setMateria(rs.getString("materia"));
            } else {
                return null;
            }
            conexion.close();

        } catch (Exception ex) {
            System.err.println("Error " + ex.getMessage());
            return null;
        }
        return e;
    }

    public boolean eliminar(Estudiante estudiante) {
        try {
            Connection conexion = getConnection();
            ps = conexion.prepareStatement("delete from estudiante where codigoe=?");
            ps.setInt(1, estudiante.getCodigo());
            var resultado = ps.executeUpdate();
            if (resultado > 0) {
                return true;
            } else {
                return false;
            }

        } catch (SQLException ex) {
            System.err.println("Error No se puedel leer el archivo ");
            return false;
        }
    }

    public Estudiante siguiente(Estudiante estudiante) {
        Estudiante e = new Estudiante();
        try {
            Connection conexion = getConnection();
            ps = conexion.prepareStatement("select * from estudiante ", rs.TYPE_SCROLL_INSENSITIVE,
                    rs.CONCUR_UPDATABLE);
            rs = ps.executeQuery();
            rs.absolute(estudiante.getCodigo());
            if (rs.next()) {
                e.setCodigo(rs.getInt("codigoE"));
                e.setNombre(rs.getString("nombreE"));
                e.setNota(rs.getDouble("nota"));
                e.setGenero(rs.getString("sexo"));
                e.setMateria(rs.getString("materia"));
                return e;
            }
        } catch (NumberFormatException | SQLException ex) {
            System.err.println("Error " + ex.getMessage());
            return null;
        }

        return null;
    }

    public Estudiante anterior(Estudiante estudiante) {
        Estudiante e = new Estudiante();
        try {
            Connection conexion = getConnection();
            ps = conexion.prepareStatement("select * from estudiante ", rs.TYPE_SCROLL_INSENSITIVE,
                    rs.CONCUR_UPDATABLE);
            rs = ps.executeQuery();
            rs.absolute(estudiante.getCodigo());

            if (rs.previous()) {
                e.setCodigo(rs.getInt("codigoE"));
                e.setNombre(rs.getString("nombreE"));
                e.setNota(rs.getDouble("nota"));
                e.setGenero(rs.getString("sexo"));
                e.setMateria(rs.getString("materia"));
                return e;
            }

        } catch (NumberFormatException | SQLException ex) {
            System.err.println("Error " + ex.getMessage());
            return null;
        }
        return null;
    }
}
